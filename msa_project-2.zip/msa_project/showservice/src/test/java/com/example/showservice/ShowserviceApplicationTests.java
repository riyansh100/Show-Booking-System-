package com.example.showservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
